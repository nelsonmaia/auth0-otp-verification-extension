# Chrome Extension for accessing webtask editor

## Usage

 1. Clone this repository
 2. Go to `chrome://extensions/` and activate `developer mode`.
 3. Click on `Load unpacked extension` and select the folder containing the extension.
 4. Login to the tenant (switch tenant or reload page)
 5. Click on the chrome extension with webtask logo
