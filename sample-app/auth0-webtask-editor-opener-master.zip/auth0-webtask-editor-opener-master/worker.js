var sandboxUrls = [
  'https://sandbox8-au.it.auth0.com/api/webtask/*',
  'https://sandbox8-eu.it.auth0.com/api/webtask/*',
  'https://sandbox8-us.it.auth0.com/api/webtask/*',
  'https://sandbox8-stage2.it.auth0.com/api/webtask/*'
];

var weEditorUrl;

var captureUrl = function(details) {
  var parts = details.url.split('/api/webtask/');

  var header = details.requestHeaders.find(function(header) {
    var name = header.name.toLowerCase();
    return name === 'authorization';
  });

  try {
    var token = header.value.replace('Bearer ', '');
    weEditorUrl = parts[0] + '/edit/' + parts[1].split('/')[0] + '#token=' + token;
  } catch (e) {
    console.log('Error occurred: ', e);
  }
};

chrome.webRequest.onBeforeSendHeaders.addListener(captureUrl, { urls: sandboxUrls }, ['requestHeaders']);

var navigateToWebtask = function () {
  if (weEditorUrl) {
    window.open(weEditorUrl,'_blank');
  }

  return null;
};

chrome.browserAction.onClicked.addListener(navigateToWebtask);
